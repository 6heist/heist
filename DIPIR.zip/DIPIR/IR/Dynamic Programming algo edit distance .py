def EditDist(S1,S2,m,n):
    if m == 0:
        return n
    elif n == 0:
        return m
    
    elif S1[m-1] == S2[n-1]:
        return EditDist(S1,S2,m-1,n-1)

    return 1 + min(EditDist(S1,S2,m,n-1),
                   EditDist(S1,S2,m-1,n),
                   EditDist(S1,S2,m-1,n-1))


S1 = str(input("Enter String 1: "))
S2 = str(input("Enter String 2: "))
m = len(S1)
n= len(S2)

print("Parth More T086")
print(EditDist(S1,S2,m,n))
