# read in the documents from a file
with open("ss.txt", "r") as f:
    docs = f.readlines()

# creating a set of all unique words in the documents
words = set()
for doc in docs:
    words.update(set(doc.lower().split()))

# creating the incidence matrix
matrix = []
for doc in docs:
    row = []
    for word in words:
        if word in doc.lower().split():
            row.append(1)
        else:
            row.append(0)
    matrix.append(row)

# printing the matrix
for row in matrix:
    print(row)

