import requests
from bs4 import BeautifulSoup

url=("https://")
code=requests.get(url)

plain=code.text
s=BeautifulSoup(plain)

for link in s.find_all("a"):
    print(link.get("href"))

r = requests.get(url)
htmlContent = r.content
print(htmlContent)

soup = BeautifulSoup(htmlContent, 'html.parser')
print(soup.prettify)

title = soup.title
print(title)

para = soup.find_all('p')
print(para)

anchors = soup.find_all('a')
print(anchors)
