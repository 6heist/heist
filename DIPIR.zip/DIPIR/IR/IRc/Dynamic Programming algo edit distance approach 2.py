# print author name
print('Parth More T086')

# function to calculate the edit distance between two strings
def EditDist(s1, s2):
    # get the length of each string
    m = len(s1)
    n = len(s2)
    # create a 2D array of zeros to store the dynamic programming values
    dp = [[0 for x in range(n+1)] for x in range(m+1)]
    
    # fill in the base cases of the dynamic programming table
    for i in range(m+1):
        for j in range(n+1):
            if i == 0:
                dp[i][j] = j
            elif j == 0:
                dp[i][j] = i
            elif s1[i-1] == s2[j-1]:
                dp[i][j] = dp[i-1][j-1]
            else:
                dp[i][j] = 1 + min(dp[i][j-1], dp[i-1][j], dp[i-1][j-1])
    
    # return the final value in the dynamic programming table
    return dp[m][n]

# get input from the user
S1 = str(input("Enter a string: "))
S2 = str(input("Enter another string: "))

# calculate the edit distance and print the result
print("Edit distance for S1 and S2: ", EditDist(S1,S2))


