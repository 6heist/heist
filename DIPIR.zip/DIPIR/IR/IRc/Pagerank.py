print("T071 Soham Badame")
import numpy as np

def pagerank(M, num_iterations=100, d=0.85):
    # get the number of nodes in the graph
    N = M.shape[1]
    # generate a random initial probability vector
    v = np.random.rand(N, 1)
    # normalize the vector to ensure the probabilities sum to 1
    v = v / np.linalg.norm(v, 1)
    # calculate the transition probability matrix with damping factor d
    M_hat = (d * M) + (((1 - d) / N) * np.ones((N, N)))
    # iterate num_iterations times to calculate the stationary distribution
    for i in range(num_iterations):
        # update the probability vector using the transition probability matrix
        v = M_hat @ v
    # return the final probability vector, which represents the PageRank scores
    return v

# define a sample adjacency matrix for a graph with 3 nodes
M = np.array([[0, 1, 1],
              [1, 0, 1],
              [1, 1, 0]])

# calculate the PageRank scores using the pagerank() function
pagerank_scores = pagerank(M)

# print the PageRank scores
print(pagerank_scores)


