import sys

Counts = {}
def MapReduce(Data):
    for i in Data:
        if i.isdigit() or i == ' ':
            continue
        elif(i in Counts):
            Counts[i] +=1
        elif (i not in Counts):
            Counts[i] = 1

for file in sys.stdin:
    Data = file.lower()
    MapReduce(Data)

print('Parth More T086')
print(Counts)
