
# print author name
print("Parth More T086 \n")

# function to search for a word in a list of strings
def search(word, lst):
    # loop over each string in the list
    for s in lst:
        # if the word is in the string, return 1
        if word in s:
            return 1
    # if the word wasn't found in any strings, return 0
    return 0

# get input from the user and split into lists of words
W1 = [item for item in input("Enter 1st string: ").split()]
W2 = [item for item in input("Enter 2nd string: ").split()]
W3 = [item for item in input("Enter 3rd string: ").split()]

# get a word from the user
t = str(input("Enter a word: "))

# search for the word in each list and print out a binary vector
print("\n Vector: ",search(t,W1),search(t,W2),search(t,W3))
