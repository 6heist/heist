import scrapy

class QuoteSpider(scrapy.Spider):
    name = 'quote-spdier'
    start_urls = ['https://google.com']

    def parse(self, response):
        # define selectors for the quote text and author fields
        QUOTE_SELECTOR = '.quote'
        TEXT_SELECTOR = '.text::text'
        AUTHOR_SELECTOR = '.author::text'
        
        # loop over each quote element in the page
        for quote in response.css(QUOTE_SELECTOR):
            # extract the quote text and author using the defined selectors
            yield {
                'text': quote.css(TEXT_SELECTOR).extract_first(),
                'author': quote.css(AUTHOR_SELECTOR).extract_first(),
            }

#Run in Terminal scrapy runspider Scrappy.py
