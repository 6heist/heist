#Importing the required libraries
from xml.dom.minidom import parse
import xml.dom.minidom

#Parsing the XML file
DOMTree = xml.dom.minidom.parse("movies.xml")

#Getting the root element of the XML file
collection = DOMTree.documentElement

Checking if the root element has a 'shelf' attribute and printing its value
if collection.hasAttribute("shelf"):
print("Root element :",collection.getAttribute("shelf"))

Getting all the 'movie' elements from the XML file
movies = collection.getElementsByTagName("movie")

#Looping through each 'movie' element and printing its details
for movie in movies:
print("Movie")
print("Title: %s" % movie.getAttribute("title"))

# Getting the values of the 'type', 'format', 'rating', 'stars', and 'description' tags for each 'movie' element
for tag in ['type', 'format', 'rating', 'stars', 'description']:
    element = movie.getElementsByTagName(tag)[0]
    print("%s: %s" % (tag.capitalize(), element.childNodes[0].data))
