# Import the necessary libraries
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

# Download the necessary files (if not already downloaded)
#nltk.download('stopwords')
#nltk.download('punkt')

# Print the author's name
print("Parth T086")

# Print the list of English stopwords
print("Stopwords in English:")
print(stopwords.words('english'))

# Define a sample text
sample_text = "This is a sample sentence."

# Tokenize the sample text
text_tokens = word_tokenize(sample_text)

# Remove stopwords from the sample text
tokens_without_sw = [word for word in text_tokens if not word in stopwords.words('english')]

# Print the original and processed text
print('\n\n','~'*15,'Sample Text','~'*15,'\n')
print('Original Text:', text_tokens,'\n')
print('Text Without Stopwords:', tokens_without_sw)

# Open a file and read its content
print('\n\n','~'*15,'File Text','~'*15)
file=open(r'C:\Users\parth\Desktop\Source\Pracs\Code\Information Retrieval\SampleText.txt')
line=file.read()

# Tokenize the text from the file
file_text_tokens = word_tokenize(line)

# Remove stopwords from the text from the file
file_tokens_without_sw = [word for word in file_text_tokens if not word in stopwords.words('english')]

# Print the original and processed text
print('Original Text:', file_text_tokens)
print('Text Without Stopwords:', file_tokens_without_sw)

# Close the file
file.close()
