# Import the MRJob library
from mrjob.job import MRJob

# Define a new class CharCount that inherits from MRJob
class CharCount(MRJob):
    # Define the mapper function
    def mapper(self, _, line):
        # Iterate through each character in the line
        for char in line:
            # Check if the character is alphabetic
            if char.isalpha():
                # Emit a key-value pair of the character and a count of 1
                yield char, 1

    # Define the reducer function
    def reducer(self, char, counts):
        # Yield a key-value pair of the character and the sum of the counts
        yield char, sum(counts)

# If the script is run directly, start the MapReduce job
if __name__ == '__main__':
    CharCount.run()
