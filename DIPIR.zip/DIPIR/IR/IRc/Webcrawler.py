# Import the requests and BeautifulSoup libraries
import requests
from bs4 import BeautifulSoup

# Define the URL to scrape
url = "https://google.com"

# Send a GET request to the URL
code = requests.get(url)

# Get the plain text content of the response
plain = code.text

# Create a BeautifulSoup object from the plain text content
s = BeautifulSoup(plain)

# Iterate through all the <a> tags in the HTML and print the value of the "href" attribute
for link in s.find_all("a"):
    print(link.get("href"))

# Send another GET request to the URL to get the HTML content
r = requests.get(url)
htmlContent = r.content

# Create a BeautifulSoup object from the HTML content
soup = BeautifulSoup(htmlContent, 'html.parser')

# Print the prettified version of the HTML
print(soup.prettify)

# Get the title of the HTML document
title = soup.title
print(title)

# Get all the <p> tags in the HTML
para = soup.find_all('p')
print(para)

# Get all the <a> tags in the HTML
anchors = soup.find_all('a')
print(anchors)
