def EditDist(S1, S2, m, n):
  """
  This function calculates the edit distance between two strings.

  Args:
    S1: The first string.
    S2: The second string.
    m: The length of S1.
    n: The length of S2.

  Returns:
    The edit distance between S1 and S2.
  """

  # Base cases:
  if m == 0:
    return n
  elif n == 0:
    return m

  # If the last characters of the strings are equal,
  # the edit distance is the edit distance between the
  # prefixes of the strings.
  elif S1[m - 1] == S2[n - 1]:
    return EditDist(S1, S2, m - 1, n - 1)

  # Otherwise, the edit distance is 1 plus the minimum of
  # the edit distances between the prefixes of the strings
  # with the last character of S1 replaced with the last character of S2,
  # the edit distances between the prefixes of the strings
  # with the last character of S2 replaced with the last character of S1,
  # and the edit distance between the prefixes of the strings
  # with the last characters of the strings replaced.
  else:
    return 1 + min(EditDist(S1, S2, m, n - 1),
                   EditDist(S1, S2, m - 1, n),
                   EditDist(S1, S2, m - 1, n - 1))
