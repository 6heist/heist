print("Parth More T086 \n")
def search(t,x):

    for i in range (0,len(x)):
        if t in x:
            return 1
        else:
            return 0

W1 = [item for item in input("Enter 1st string: ").split()]
W2 = [item for item in input("Enter 2nd string: ").split()]
W3 = [item for item in input("Enter 3rd string: ").split()]

t = str(input("Enter a word: "))
print("\n Vector: ",search(t,W1),search(t,W2),search(t,W3))

