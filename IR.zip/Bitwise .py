def IRPrac1A():
    print("Parth More T086")
    no1 = int(input("Enter first number: "))
    no2 = int(input("Enter second number: "))

    print("\n\n")
    
    #operators
    print("Bitwise AND operation between: ",no1,no2, no1 & no2)
    print("Bitwise OR operation between: ",no1,no2, no1 | no2)
    print("Bitwise XOR operation between: ",no1,no2, no1 ^ no2)
    print("Bitwise NOT operation on: ",no1, ~no1 )
    print("Bitwise Leftshift operation on: ",no1,"by 2:",no1 << 2)
    print("Bitwise Rightshift operation on: ",no1,"by 2:",no1 >> 4)

IRPrac1A()




