import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

#nltk.download ('stopwords')
#nltk.download ('punkt')

print("Parth T086")

print("Stopwords in english")
print(stopwords.words('english'))

sample_text = "This is sample sentence" #sample text
text_tokens = word_tokenize(sample_text) #splitting sample text

tokens_without_sw = [word for word in text_tokens if not word in stopwords.words('english')] #removing stopwords form sample text

print('\n\n','~'*15,'Sample Text','~'*15,'\n')
print('Original Text :- ', text_tokens,'\n')
print('Text Without Stopwords :- ', tokens_without_sw)

print('\n\n','~'*15,'File Text','~'*15)
file=open(r'C:\Users\parth\Desktop\Source\Pracs\Code\Information Retrieval\SampleText.txt')
line=file.read()
file_text_tokens = word_tokenize(line)
file_tokens_without_sw = [word for word in file_text_tokens if not word in stopwords.words('english')] #removing stopwords from given text file 

print('Original Text :- ', file_text_tokens)
print('Text Without Stopwords :- ', file_tokens_without_sw)
file.close()
