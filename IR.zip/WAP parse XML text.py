from xml.dom.minidom import parse
import xml.dom.minidom

DOMTree = xml.dom.minidom.parse("movies.xml")

collection = DOMTree.documentElement
if collection.hasAttribute("shelf"):
   print("Root element :",collection.getAttribute("shelf"))
   
movies = collection.getElementsByTagName("movie")
for movie in movies:
    print("*****Movie*****")
    print("Title: %s" % movie.getAttribute("title"))

    for tag in ['type', 'format', 'rating', 'stars', 'description']:
        element = movie.getElementsByTagName(tag)[0]
        print("%s: %s" % (tag.capitalize(), element.childNodes[0].data))
